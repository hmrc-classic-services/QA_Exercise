trait TestProperties {
  val host = "http://localhost:8090/"
  val createEventPage =  "http://localhost:8090/addEvent"
}
